/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

/**
 *
 * @author Badoed
 */
    
public class Mobil {
    private String Id;
    private String NoPolisi;
    private String Merk;
    private String Warna;
    
    
    public Mobil(String Id, String NoPolisi, String Merk, String Warna ) {
        this.Id= Id;
        this.NoPolisi = NoPolisi;
        this.Merk = Merk;
        this.Warna = Warna;    
        }
    

    @Override
    public boolean equals(Object obj) {
        Mobil mbl = (Mobil) obj;
        if(this.Id.equals(mbl.getId())) return true;
        else return false;
    }
    
    @Override
    public String toString() {
        return "[ " + Id + ", " + " ," + NoPolisi + ", " + Merk + ", " + Warna + ", " + "];";
    }
    

    public void Id(String Id) { 
        this.Id = Id; 
    }

    public String getId() { 
        return Id; 
    }
    
   
    public void NoPolisi(String NoPolisi) { 
        this.NoPolisi = NoPolisi; 
    }

    public String getNoPolisi() { 
        return NoPolisi; 
    }

    public void setMerk(String Merk) { 
        this.Merk = Merk; 
    }

    public String getMerk() { 
        return Merk; 
    }

    public void setWarna(String Warna) { 
        this.Warna = Warna; 
    }

    public String getWarna() { 
        return Warna; 
    }
    
  
    
}

