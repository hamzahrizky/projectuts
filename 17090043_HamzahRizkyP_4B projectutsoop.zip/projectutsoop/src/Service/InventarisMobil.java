package Service;

import java.util.LinkedList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Badoed
 */
public class InventarisMobil {
    
private static List<Mobil> data = new LinkedList<Mobil>();
    public void tambahData(Mobil mbl){
    data.add(mbl);
        System.out.println("Data sudah tersimpan");
    }
    public void ubahData(Mobil mbl){
    int idx=data.indexOf(mbl);
    if(idx >=0) data.set(idx,mbl);
        System.out.println("Data sudah berubah");
    }
    
    public void hapusData(String Id){
    int idx=data.indexOf(new Mobil(Id ,"", "",""));
    if(idx >= 0) data.remove(idx);
        System.out.println("Data telah terhapus");
    }
    
    public void tampilkanData(){
        System.out.println("\n--= Isi Data =--");
        int urutan =1;
        for(Mobil mbl : data){
            System.out.println("\nData ke- :" + urutan++);
            System.out.println("Id  :" + mbl.getId());
            System.out.println("No Polisi :" + mbl.getNoPolisi());
            System.out.println("Merk :" + mbl.getMerk());
            System.out.println("Warna :" + mbl.getWarna());
           
            
            
        }
    }
    
}
    

