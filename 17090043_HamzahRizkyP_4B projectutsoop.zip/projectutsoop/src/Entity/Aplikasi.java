/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import Service.InventarisMobil;
import Service.Mobil;
import java.util.Scanner;


/**
 *
 * @author Badoed
 */
public class Aplikasi {
    private static Scanner scanner;
    private static InventarisMobil service = new InventarisMobil();
    
    public static void main(String[] args) {
        int opsi =5;
        do{
        tampilkanMenu();
            scanner = new Scanner(System.in);
            opsi = scanner.nextInt();
            proses(opsi);
    }while(opsi !=5);
    }
    

private static void proses(int opsi){
        switch(opsi){
            case 1:
                tampilkanFormTambahData();
                break;
            case 2:
                tampilkanFormUbahData();
                break;
            case 3:
                 tampilkanFormHapusData();
                break;
            case 4:
                service.tampilkanData();
                break;
        }
    }
    

private static void tampilkanFormUbahData(){
        scanner= new Scanner(System.in);
        String Id, NamaPeminjam, NoPolisi, Merk, Warna, TglPinjam, TglPengembalian;
        
        System.out.println("--= Form Ubah Data=--");
        System.out.print("Id :");
        Id = scanner.nextLine();
        System.out.print("No Polisi :");
        NoPolisi = scanner.nextLine();
        System.out.print("Merk :");
        Merk = scanner.nextLine();
        System.out.print("Warna :");
        Warna = scanner.nextLine();
        
        
        
        service.ubahData(new Mobil(Id, NoPolisi, Merk, Warna));
        
    }


 private static void tampilkanFormHapusData() {
        scanner = new Scanner(System.in);
        String Id;

        System.out.println("\n--- Form Hapus Data ---");
        System.out.print("Id : ");
        Id= scanner.nextLine();
        service.hapusData(Id);
    }
 

private static void tampilkanFormTambahData(){
        scanner= new Scanner(System.in);
        String Id, NamaPeminjam, NoPolisi, Merk, Warna, TglPinjam, TglPengembalian;
        
        System.out.println("\n--= Form Tambah Data=--");
        System.out.print("Id :");
        Id = scanner.nextLine();
        System.out.print("No Polisi :");
        NoPolisi = scanner.nextLine();
        System.out.print("Merk :");
        Merk = scanner.nextLine();
        System.out.print("Warna :");
        Warna = scanner.nextLine();
        
        
        
        service.tambahData(new Mobil(Id, NoPolisi, Merk, Warna));
        
    }


private static void  tampilkanMenu(){
        System.out.println("\n--= Menu Aplikasi Inventaris Mobil =--");
        System.out.println("1. Tambah Data");
        System.out.println("2. Ubah Data");
        System.out.println("3. Hapus Data");
        System.out.println("4. Tampilkan Data");
        System.out.println("5. KELUAR");
        System.out.println("-------------------");
        System.out.print("opsi >");
        
    }
    
}

    

